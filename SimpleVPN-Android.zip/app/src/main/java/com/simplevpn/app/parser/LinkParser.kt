package com.simplevpn.app.parser

import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.simplevpn.app.data.VpnProfile
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLDecoder

object LinkParser {
    private val gson = Gson()

    fun importInput(rawInput: String): List<VpnProfile> {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return emptyList()

        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            val body = fetchSubscription(trimmed)
            return parseMultipleLinks(body)
        }
        return parseMultipleLinks(trimmed)
    }

    private fun fetchSubscription(urlStr: String): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 12_000
            setRequestProperty("User-Agent", "v2rayNG/1.9.0")
        }
        val code = conn.responseCode
        if (code !in 200..299) {
            throw IllegalStateException("Сервер подписки вернул код $code")
        }
        val raw = conn.inputStream.bufferedReader().use { it.readText() }.trim()
        conn.disconnect()
        return tryDecodeBase64Subscription(raw)
    }

    private fun tryDecodeBase64Subscription(content: String): String {
        val lower = content.lowercase()
        if (lower.contains("vless://") || lower.contains("vmess://") ||
            lower.contains("trojan://") || lower.contains("ss://")
        ) {
            return content
        }
        return try {
            decodeBase64Flex(content)
        } catch (_: Exception) {
            content
        }
    }

    fun parseMultipleLinks(text: String): List<VpnProfile> {
        val decoded = tryDecodeBase64Subscription(text.trim())
        return decoded
            .lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .mapNotNull { line ->
                runCatching { parseSingleLink(line) }.getOrNull()
            }
    }

    fun parseSingleLink(link: String): VpnProfile? {
        val trimmed = link.trim()
        return when {
            trimmed.startsWith("vless://", ignoreCase = true) -> parseVless(trimmed)
            trimmed.startsWith("trojan://", ignoreCase = true) -> parseTrojan(trimmed)
            trimmed.startsWith("vmess://", ignoreCase = true) -> parseVmess(trimmed)
            trimmed.startsWith("ss://", ignoreCase = true) -> parseShadowsocks(trimmed)
            else -> null
        }
    }

    private fun parseVless(link: String): VpnProfile {
        val uri = URI(link)
        val uuid = uri.userInfo ?: throw IllegalArgumentException("VLESS: отсутствует UUID")
        val host = uri.host ?: throw IllegalArgumentException("VLESS: отсутствует хост")
        val port = if (uri.port > 0) uri.port else 443
        val params = parseQuery(uri.rawQuery)
        val remark = decodeUriComponent(uri.rawFragment).ifBlank { "$host:$port" }

        val user = JsonObject().apply {
            addProperty("id", uuid)
            addProperty("encryption", params["encryption"]?.ifBlank { "none" } ?: "none")
            val flow = params["flow"]
            if (!flow.isNullOrBlank()) {
                addProperty("flow", flow)
            }
        }

        val vnextItem = JsonObject().apply {
            addProperty("address", host)
            addProperty("port", port)
            add("users", JsonArray().apply { add(user) })
        }

        val outbound = JsonObject().apply {
            addProperty("tag", "proxy")
            addProperty("protocol", "vless")
            add("settings", JsonObject().apply {
                add("vnext", JsonArray().apply { add(vnextItem) })
            })
            add("streamSettings", buildStreamSettings(params, host, defaultSecurity = "none"))
        }

        return VpnProfile(
            name = remark,
            protocol = "VLESS",
            rawUri = link,
            host = host,
            port = port,
            outboundJson = gson.toJson(outbound)
        )
    }

    private fun parseTrojan(link: String): VpnProfile {
        val uri = URI(link)
        val password = decodeUriComponent(uri.rawUserInfo)
        val host = uri.host ?: throw IllegalArgumentException("Trojan: отсутствует хост")
        val port = if (uri.port > 0) uri.port else 443
        val params = parseQuery(uri.rawQuery)
        val remark = decodeUriComponent(uri.rawFragment).ifBlank { "$host:$port" }

        val server = JsonObject().apply {
            addProperty("address", host)
            addProperty("port", port)
            addProperty("password", password)
        }

        val outbound = JsonObject().apply {
            addProperty("tag", "proxy")
            addProperty("protocol", "trojan")
            add("settings", JsonObject().apply {
                add("servers", JsonArray().apply { add(server) })
            })
            add("streamSettings", buildStreamSettings(params, host, defaultSecurity = "tls"))
        }

        return VpnProfile(
            name = remark,
            protocol = "TROJAN",
            rawUri = link,
            host = host,
            port = port,
            outboundJson = gson.toJson(outbound)
        )
    }

    private fun parseVmess(link: String): VpnProfile {
        val payload = link.removePrefix("vmess://").removePrefix("VMESS://").trim()
        val jsonStr = decodeBase64Flex(payload)
        val obj = JsonParser.parseString(jsonStr).asJsonObject

        val host = obj.get("add")?.asString ?: throw IllegalArgumentException("VMess: нет адреса")
        val port = obj.get("port")?.asString?.toIntOrNull() ?: 443
        val uuid = obj.get("id")?.asString ?: throw IllegalArgumentException("VMess: нет ID")
        val remark = obj.get("ps")?.asString?.ifBlank { "$host:$port" } ?: "$host:$port"
        val security = obj.get("scy")?.asString?.ifBlank { "auto" } ?: "auto"
        val net = obj.get("net")?.asString?.ifBlank { "tcp" } ?: "tcp"
        val tls = obj.get("tls")?.asString ?: ""
        val sni = obj.get("sni")?.asString?.ifBlank { obj.get("host")?.asString ?: host } ?: host

        val params = mutableMapOf<String, String>()
        params["type"] = net
        params["security"] = if (tls.equals("tls", ignoreCase = true)) "tls" else "none"
        params["sni"] = sni
        obj.get("host")?.asString?.let { params["host"] = it }
        obj.get("path")?.asString?.let { params["path"] = it }
        obj.get("fp")?.asString?.let { params["fp"] = it }
        obj.get("alpn")?.asString?.let { params["alpn"] = it }
        obj.get("type")?.asString?.let { params["headerType"] = it }
        if (net == "grpc") {
            obj.get("path")?.asString?.let { params["serviceName"] = it }
        }

        val user = JsonObject().apply {
            addProperty("id", uuid)
            addProperty("security", security)
        }

        val vnextItem = JsonObject().apply {
            addProperty("address", host)
            addProperty("port", port)
            add("users", JsonArray().apply { add(user) })
        }

        val outbound = JsonObject().apply {
            addProperty("tag", "proxy")
            addProperty("protocol", "vmess")
            add("settings", JsonObject().apply {
                add("vnext", JsonArray().apply { add(vnextItem) })
            })
            add("streamSettings", buildStreamSettings(params, host, defaultSecurity = "none"))
        }

        return VpnProfile(
            name = remark,
            protocol = "VMESS",
            rawUri = link,
            host = host,
            port = port,
            outboundJson = gson.toJson(outbound)
        )
    }

    private fun parseShadowsocks(link: String): VpnProfile {
        val withoutScheme = link.substringAfter("://")
        val fragment = withoutScheme.substringAfter("#", "")
        val remark = decodeUriComponent(fragment)
        val mainPart = withoutScheme.substringBefore("#").substringBefore("?")

        val method: String
        val password: String
        val host: String
        val port: Int

        if (mainPart.contains("@")) {
            val userInfoRaw = mainPart.substringBefore("@")
            val hostPort = mainPart.substringAfter("@")
            val userInfo = if (userInfoRaw.contains(":")) {
                decodeUriComponent(userInfoRaw)
            } else {
                decodeBase64Flex(userInfoRaw)
            }
            method = userInfo.substringBefore(":")
            password = userInfo.substringAfter(":")
            host = hostPort.substringBeforeLast(":").trim('[', ']')
            port = hostPort.substringAfterLast(":").toInt()
        } else {
            val decoded = decodeBase64Flex(mainPart)
            val userInfo = decoded.substringBefore("@")
            val hostPort = decoded.substringAfter("@")
            method = userInfo.substringBefore(":")
            password = userInfo.substringAfter(":")
            host = hostPort.substringBeforeLast(":").trim('[', ']')
            port = hostPort.substringAfterLast(":").toInt()
        }

        val server = JsonObject().apply {
            addProperty("address", host)
            addProperty("port", port)
            addProperty("method", method)
            addProperty("password", password)
        }

        val outbound = JsonObject().apply {
            addProperty("tag", "proxy")
            addProperty("protocol", "shadowsocks")
            add("settings", JsonObject().apply {
                add("servers", JsonArray().apply { add(server) })
            })
        }

        return VpnProfile(
            name = remark.ifBlank { "$host:$port" },
            protocol = "SS",
            rawUri = link,
            host = host,
            port = port,
            outboundJson = gson.toJson(outbound)
        )
    }

    private fun buildStreamSettings(
        params: Map<String, String>,
        defaultHost: String,
        defaultSecurity: String
    ): JsonObject {
        val networkRaw = params["type"]?.lowercase()?.ifBlank { "tcp" } ?: "tcp"
        val network = when (networkRaw) {
            "tcp" -> "raw"
            "splithttp" -> "xhttp"
            else -> networkRaw
        }
        val security = params["security"]?.lowercase()?.ifBlank { defaultSecurity } ?: defaultSecurity

        return JsonObject().apply {
            addProperty("network", network)
            addProperty("security", security)

            when (security) {
                "tls" -> {
                    add("tlsSettings", JsonObject().apply {
                        val sni = params["sni"]?.ifBlank { params["host"] }?.ifBlank { defaultHost } ?: defaultHost
                        addProperty("serverName", sni)
                        val fp = params["fp"]?.ifBlank { "chrome" } ?: "chrome"
                        addProperty("fingerprint", fp)
                        val alpn = params["alpn"]
                        if (!alpn.isNullOrBlank()) {
                            add("alpn", JsonArray().apply {
                                alpn.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { add(it) }
                            })
                        }
                    })
                }
                "reality" -> {
                    add("realitySettings", JsonObject().apply {
                        val sni = params["sni"]?.ifBlank { defaultHost } ?: defaultHost
                        addProperty("serverName", sni)
                        addProperty("fingerprint", params["fp"]?.ifBlank { "chrome" } ?: "chrome")
                        addProperty("publicKey", params["pbk"] ?: "")
                        addProperty("shortId", params["sid"] ?: "")
                        addProperty("spiderX", params["spx"] ?: "")
                    })
                }
            }

            when (network) {
                "ws" -> {
                    add("wsSettings", JsonObject().apply {
                        addProperty("path", params["path"]?.ifBlank { "/" } ?: "/")
                        val wsHost = params["host"]
                        if (!wsHost.isNullOrBlank()) {
                            addProperty("host", wsHost)
                        }
                    })
                }
                "grpc" -> {
                    add("grpcSettings", JsonObject().apply {
                        addProperty("serviceName", params["serviceName"] ?: params["path"] ?: "")
                        if (params["mode"] == "multi") {
                            addProperty("multiMode", true)
                        }
                    })
                }
                "httpupgrade" -> {
                    add("httpupgradeSettings", JsonObject().apply {
                        addProperty("path", params["path"]?.ifBlank { "/" } ?: "/")
                        val h = params["host"]
                        if (!h.isNullOrBlank()) addProperty("host", h)
                    })
                }
                "xhttp" -> {
                    add("xhttpSettings", JsonObject().apply {
                        addProperty("path", params["path"]?.ifBlank { "/" } ?: "/")
                        val h = params["host"]
                        if (!h.isNullOrBlank()) addProperty("host", h)
                        val mode = params["mode"]
                        if (!mode.isNullOrBlank()) addProperty("mode", mode)
                    })
                }
            }
        }
    }

    fun buildFullXrayConfig(profile: VpnProfile): String {
        val root = JsonObject().apply {
            add("log", JsonObject().apply {
                addProperty("loglevel", "warning")
            })

            add("inbounds", JsonArray().apply {
                add(JsonObject().apply {
                    addProperty("tag", "tun-in")
                    addProperty("port", 0)
                    addProperty("protocol", "tun")
                    add("settings", JsonObject().apply {
                        addProperty("name", "xray0")
                        addProperty("mtu", 1500)
                    })
                    add("sniffing", JsonObject().apply {
                        addProperty("enabled", true)
                        add("destOverride", JsonArray().apply {
                            add("http")
                            add("tls")
                            add("quic")
                        })
                    })
                })
            })

            add("outbounds", JsonArray().apply {
                add(JsonParser.parseString(profile.outboundJson).asJsonObject)
                add(JsonObject().apply {
                    addProperty("tag", "direct")
                    addProperty("protocol", "freedom")
                })
            })

            add("routing", JsonObject().apply {
                addProperty("domainStrategy", "AsIs")
                add("rules", JsonArray().apply {
                    add(JsonObject().apply {
                        addProperty("type", "field")
                        add("ip", JsonArray().apply {
                            add("10.0.0.0/8")
                            add("172.16.0.0/12")
                            add("192.168.0.0/16")
                            add("127.0.0.0/8")
                        })
                        addProperty("outboundTag", "direct")
                    })
                })
            })
        }
        return gson.toJson(root)
    }

    private fun parseQuery(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrBlank()) return emptyMap()
        return rawQuery.split("&")
            .mapNotNull { pair ->
                val idx = pair.indexOf('=')
                if (idx <= 0) null
                else decodeUriComponent(pair.substring(0, idx)) to decodeUriComponent(pair.substring(idx + 1))
            }
            .toMap()
    }

    private fun decodeUriComponent(value: String?): String {
        if (value.isNullOrEmpty()) return ""
        return try {
            URLDecoder.decode(value.replace("+", "%2B"), "UTF-8")
        } catch (_: Exception) {
            value
        }
    }

    private fun decodeBase64Flex(input: String): String {
        val cleaned = input.trim().replace('-', '+').replace('_', '/').replace("\s".toRegex(), "")
        val padded = when (cleaned.length % 4) {
            2 -> "$cleaned=="
            3 -> "$cleaned="
            else -> cleaned
        }
        return String(Base64.decode(padded, Base64.DEFAULT), Charsets.UTF_8)
    }
}
