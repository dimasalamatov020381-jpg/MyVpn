package com.simplevpn.app.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class Storage(context: Context) {
    private val prefs = context.getSharedPreferences("simple_vpn_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getProfiles(): List<VpnProfile> {
        val json = prefs.getString("profiles", null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<VpnProfile>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveProfiles(profiles: List<VpnProfile>) {
        prefs.edit().putString("profiles", gson.toJson(profiles)).apply()
    }

    fun getSettings(): AppSettings {
        val json = prefs.getString("settings", null) ?: return AppSettings()
        return try {
            gson.fromJson(json, AppSettings::class.java) ?: AppSettings()
        } catch (_: Exception) {
            AppSettings()
        }
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit().putString("settings", gson.toJson(settings)).apply()
    }
}
