package com.simplevpn.app.parser

import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.simplevpn.app.data.VpnProfile
import com.simplevpn.app.vpn.VpnStateHolder
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.util.zip.GZIPInputStream

object LinkParser {
    private val gson = Gson()

    private val USER_AGENTS = listOf(
        "v2rayNG/1.9.16",
        "Happ/2.5.0",
        "HiddifyNext/2.0.5",
        "Shadowrocket/2100"
    )

    fun importInput(rawInput: String): List<VpnProfile> {
        val cleaned = rawInput
            .replace("\uFEFF", "")
            .replace("\u200B", "")
            .trim()
            .trim('"', '\'', '`')
        if (cleaned.isEmpty()) return emptyList()

        // Если вставлен URL подписки (в любом регистре, например Https://...)
        if (cleaned.startsWith("http://", ignoreCase = true) ||
            cleaned.startsWith("https://", ignoreCase = true)
        ) {
            val normalizedUrl = when {
                cleaned.startsWith("https://", ignoreCase = true) -> "https://" + cleaned.substring(8)
                else -> "http://" + cleaned.substring(7)
            }.substringBefore(" ").substringBefore("\n").trim()

            return importFromSubscriptionUrl(normalizedUrl)
        }

        if (cleaned.startsWith("happ://", ignoreCase = true)) {
            VpnStateHolder.addLog("Обнаружена закрытая ссылка happ://")
            throw IllegalStateException(
                "Ссылка в закрытом формате happ:// — его расшифровывает только само приложение Happ. Возьми обычную ссылку подписки (https://) или vless://"
            )
        }

        val profiles = parseContent(cleaned)
        VpnStateHolder.addLog("Импорт текста: найдено серверов — ${profiles.size}")
        return profiles
    }

    private fun importFromSubscriptionUrl(urlStr: String): List<VpnProfile> {
        VpnStateHolder.addLog("Загрузка подписки: $urlStr")
        var lastBody = ""
        var lastError: Exception? = null
        var sawHappCrypt = false
        var sawHtml = false

        for (ua in USER_AGENTS) {
            try {
                val body = fetchUrlWithRedirects(urlStr, ua)
                lastBody = body
                val preview = body.replace("\r", " ").replace("\n", " ").take(140)
                VpnStateHolder.addLog("UA=$ua -> получено ${body.length} байт: $preview")

                val lower = body.trim().lowercase()
                if (lower.startsWith("happ://crypt") || lower.contains("happ://crypt")) {
                    sawHappCrypt = true
                    continue
                }
                if (lower.startsWith("<!doctype") || lower.startsWith("<html") || lower.contains("<html")) {
                    sawHtml = true
                    continue
                }

                val parsed = parseContent(body)
                if (parsed.isNotEmpty()) {
                    VpnStateHolder.addLog("Успешно разобрано серверов: ${parsed.size} (UA=$ua)")
                    return parsed
                }
            } catch (e: Exception) {
                lastError = e
                VpnStateHolder.addLog("Ошибка при UA=$ua: ${e.message}")
            }
        }

        if (sawHappCrypt) {
            throw IllegalStateException(
                "Сервер отдал зашифрованную подписку Happ (happ://crypt). Для SimpleVPN нужна обычная v2ray/VLESS-ссылка из бота или кабинета"
            )
        }
        if (sawHtml) {
            throw IllegalStateException(
                "Сервер подписки вернул HTML-страницу вместо ключей (возможно, защита Cloudflare или неверная ссылка). Подробности в Логах"
            )
        }
        if (lastBody.isBlank() && lastError != null) {
            throw lastError
        }
        VpnStateHolder.addLog("Не удалось найти ключи в ответе сервера. Проверь ответ выше.")
        return emptyList()
    }

    private fun fetchUrlWithRedirects(initialUrl: String, userAgent: String): String {
        var currentUrl = initialUrl
        for (hop in 0..5) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                instanceFollowRedirects = false
                connectTimeout = 15_000
                readTimeout = 15_000
                setRequestProperty("User-Agent", userAgent)
                setRequestProperty("Accept", "*/*")
                setRequestProperty("Accept-Encoding", "gzip, identity")
            }
            val code = conn.responseCode
            if (code in listOf(301, 302, 303, 307, 308)) {
                val location = conn.getHeaderField("Location")
                conn.disconnect()
                if (location.isNullOrBlank()) {
                    throw IllegalStateException("Редирект $code без адреса")
                }
                currentUrl = URL(URL(currentUrl), location).toString()
                continue
            }
            if (code !in 200..299) {
                conn.disconnect()
                throw IllegalStateException("Сервер подписки вернул HTTP $code")
            }
            val encoding = conn.contentEncoding?.lowercase() ?: ""
            val rawStream: InputStream = if (encoding.contains("gzip")) {
                GZIPInputStream(conn.inputStream)
            } else {
                conn.inputStream
            }
            val text = rawStream.bufferedReader(Charsets.UTF_8).use { it.readText() }.trim()
            conn.disconnect()
            return text
        }
        throw IllegalStateException("Слишком много перенаправлений при загрузке подписки")
    }

    fun parseContent(rawContent: String): List<VpnProfile> {
        val trimmed = rawContent.replace("\uFEFF", "").trim()
        if (trimmed.isEmpty()) return emptyList()

        // 1. Проверка, не JSON ли это (Xray JSON конфиг или массив конфигов)
        if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
            val jsonProfiles = runCatching { parseXrayJsonSubscription(trimmed) }.getOrDefault(emptyList())
            if (jsonProfiles.isNotEmpty()) return jsonProfiles
        }

        // 2. Попытка разобрать как список URI (напрямую или после Base64-декодирования)
        val candidates = mutableListOf(trimmed)
        if (!containsKnownScheme(trimmed)) {
            val nonCommentBody = trimmed.lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .joinToString("")
            if (nonCommentBody.isNotEmpty()) {
                runCatching { decodeBase64Flex(nonCommentBody) }.getOrNull()?.let { decoded ->
                    candidates.add(decoded)
                }
            }
        }

        for (candidate in candidates) {
            val t = candidate.trim()
            if (t.startsWith("{") || t.startsWith("[")) {
                val jsonProfiles = runCatching { parseXrayJsonSubscription(t) }.getOrDefault(emptyList())
                if (jsonProfiles.isNotEmpty()) return jsonProfiles
            }

            val parsed = parseMultipleLinks(t)
            if (parsed.isNotEmpty()) return parsed
        }
        return emptyList()
    }

    private fun containsKnownScheme(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("vless://") ||
            lower.contains("vmess://") ||
            lower.contains("trojan://") ||
            lower.contains("ss://")
    }

    private fun parseXrayJsonSubscription(jsonText: String): List<VpnProfile> {
        val element = JsonParser.parseString(jsonText)
        val result = mutableListOf<VpnProfile>()

        fun extractFromConfigObj(obj: JsonObject, fallbackIndex: Int) {
            val remarks = obj.get("remarks")?.asString
                ?: obj.get("remark")?.asString
                ?: obj.get("name")?.asString
                ?: "Сервер #$fallbackIndex"
            val outbounds = obj.getAsJsonArray("outbounds") ?: return
            for (obEl in outbounds) {
                if (!obEl.isJsonObject) continue
                val ob = obEl.asJsonObject.deepCopy()
                val proto = ob.get("protocol")?.asString?.lowercase() ?: continue
                if (proto !in listOf("vless", "vmess", "trojan", "shadowsocks")) continue
                ob.addProperty("tag", "proxy")

                var host = "server"
                var port = 443
                val settings = ob.getAsJsonObject("settings")
                val vnext = settings?.getAsJsonArray("vnext")?.firstOrNull()?.asJsonObject
                val servers = settings?.getAsJsonArray("servers")?.firstOrNull()?.asJsonObject
                if (vnext != null) {
                    host = vnext.get("address")?.asString ?: host
                    port = vnext.get("port")?.asInt ?: port
                } else if (servers != null) {
                    host = servers.get("address")?.asString ?: host
                    port = servers.get("port")?.asInt ?: port
                }

                result.add(
                    VpnProfile(
                        name = remarks.ifBlank { "$host:$port" },
                        protocol = if (proto == "shadowsocks") "SS" else proto.uppercase(),
                        rawUri = "json://$host:$port",
                        host = host,
                        port = port,
                        outboundJson = gson.toJson(ob)
                    )
                )
                break
            }
        }

        when {
            element.isJsonArray -> {
                element.asJsonArray.forEachIndexed { idx, item ->
                    if (item.isJsonObject) extractFromConfigObj(item.asJsonObject, idx + 1)
                }
            }
            element.isJsonObject -> {
                extractFromConfigObj(element.asJsonObject, 1)
            }
        }
        return result
    }

    fun parseMultipleLinks(text: String): List<VpnProfile> {
        val result = mutableListOf<VpnProfile>()
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
        for (line in lines) {
            try {
                parseSingleLink(line)?.let { result.add(it) }
            } catch (e: Exception) {
                VpnStateHolder.addLog("Пропуск строки (${line.take(24)}...): ${e.message}")
            }
        }
        return result
    }

    fun parseSingleLink(link: String): VpnProfile? {
        val trimmed = link.trim()
        return when {
            trimmed.startsWith("vless://", ignoreCase = true) -> parseVless(trimmed)
            trimmed.startsWith("trojan://", ignoreCase = true) -> parseTrojan(trimmed)
            trimmed.startsWith("vmess://", ignoreCase = true) -> parseVmess(trimmed)
            trimmed.startsWith("ss://", ignoreCase = true) -> parseShadowsocks(trimmed)
            else -> null
        }
    }

    private data class SplitUri(
        val userInfo: String,
        val host: String,
        val port: Int,
        val params: Map<String, String>,
        val remark: String
    )

    // Безопасный ручной разбор URI: не падает на пробелах, эмодзи, кириллице и символах '|' в названии
    private fun splitGenericUri(link: String, defaultPort: Int = 443): SplitUri {
        val withoutScheme = link.substringAfter("://")
        val hashIdx = withoutScheme.indexOf('#')
        val mainPart = if (hashIdx >= 0) withoutScheme.substring(0, hashIdx) else withoutScheme
        val rawFragment = if (hashIdx >= 0) withoutScheme.substring(hashIdx + 1) else ""

        val qIdx = mainPart.indexOf('?')
        val authorityAndPath = if (qIdx >= 0) mainPart.substring(0, qIdx) else mainPart
        val rawQuery = if (qIdx >= 0) mainPart.substring(qIdx + 1) else ""

        val authority = authorityAndPath.substringBefore("/")
        val atIdx = authority.lastIndexOf('@')
        if (atIdx <= 0) throw IllegalArgumentException("нет учётных данных перед @")

        val userInfo = decodeUriComponent(authority.substring(0, atIdx))
        val hostPort = authority.substring(atIdx + 1).trim()

        val host: String
        val port: Int
        if (hostPort.startsWith("[")) {
            val closeBracket = hostPort.indexOf(']')
            if (closeBracket < 0) throw IllegalArgumentException("некорректный IPv6 хост")
            host = hostPort.substring(1, closeBracket)
            val portStr = hostPort.substring(closeBracket + 1).removePrefix(":")
            port = portStr.toIntOrNull() ?: defaultPort
        } else {
            val colonIdx = hostPort.lastIndexOf(':')
            if (colonIdx > 0) {
                host = hostPort.substring(0, colonIdx)
                port = hostPort.substring(colonIdx + 1).toIntOrNull() ?: defaultPort
            } else {
                host = hostPort
                port = defaultPort
            }
        }

        if (host.isBlank()) throw IllegalArgumentException("пустой хост")
        val params = parseQuery(rawQuery)
        val remark = decodeUriComponent(rawFragment).ifBlank { "$host:$port" }
        return SplitUri(userInfo, host, port, params, remark)
    }

    private fun parseVless(link: String): VpnProfile {
        val p = splitGenericUri(link)

        val user = JsonObject().apply {
            addProperty("id", p.userInfo)
            addProperty("encryption", p.params["encryption"]?.ifBlank { "none" } ?: "none")
            val flow = p.params["flow"]
            if (!flow.isNullOrBlank()) {
                addProperty("flow", flow)
            }
        }

        val vnextItem = JsonObject().apply {
            addProperty("address", p.host)
            addProperty("port", p.port)
            add("users", JsonArray().apply { add(user) })
        }

        val outbound = JsonObject().apply {
            addProperty("tag", "proxy")
            addProperty("protocol", "vless")
            add("settings", JsonObject().apply {
                add("vnext", JsonArray().apply { add(vnextItem) })
            })
            add("streamSettings", buildStreamSettings(p.params, p.host, defaultSecurity = "none"))
        }

        return VpnProfile(
            name = p.remark,
            protocol = "VLESS",
            rawUri = link,
            host = p.host,
            port = p.port,
            outboundJson = gson.toJson(outbound)
        )
    }

    private fun parseTrojan(link: String): VpnProfile {
        val p = splitGenericUri(link)

        val server = JsonObject().apply {
            addProperty("address", p.host)
            addProperty("port", p.port)
            addProperty("password", p.userInfo)
        }

        val outbound = JsonObject().apply {
            addProperty("tag", "proxy")
            addProperty("protocol", "trojan")
            add("settings", JsonObject().apply {
                add("servers", JsonArray().apply { add(server) })
            })
            add("streamSettings", buildStreamSettings(p.params, p.host, defaultSecurity = "tls"))
        }

        return VpnProfile(
            name = p.remark,
            protocol = "TROJAN",
            rawUri = link,
            host = p.host,
            port = p.port,
            outboundJson = gson.toJson(outbound)
        )
    }

    private fun parseVmess(link: String): VpnProfile {
        val payload = link.substringAfter("://").trim()
        val jsonStr = decodeBase64Flex(payload)
        val obj = JsonParser.parseString(jsonStr).asJsonObject

        val host = obj.get("add")?.asString ?: throw IllegalArgumentException("VMess: нет адреса")
        val port = obj.get("port")?.asString?.toIntOrNull() ?: 443
        val uuid = obj.get("id")?.asString ?: throw IllegalArgumentException("VMess: нет ID")
        val remark = obj.get("ps")?.asString?.ifBlank { "$host:$port" } ?: "$host:$port"
        val security = obj.get("scy")?.asString?.ifBlank { "auto" } ?: "auto"
        val net = obj.get("net")?.asString?.ifBlank { "tcp" } ?: "tcp"
        val tls = obj.get("tls")?.asString ?: ""
        val sni = obj.get("sni")?.asString?.ifBlank { obj.get("host")?.asString ?: host } ?: host

        val params = mutableMapOf<String, String>()
        params["type"] = net
        params["security"] = if (tls.equals("tls", ignoreCase = true)) "tls" else "none"
        params["sni"] = sni
        obj.get("host")?.asString?.let { params["host"] = it }
        obj.get("path")?.asString?.let { params["path"] = it }
        obj.get("fp")?.asString?.let { params["fp"] = it }
        obj.get("alpn")?.asString?.let { params["alpn"] = it }
        obj.get("type")?.asString?.let { params["headerType"] = it }
        if (net == "grpc") {
            obj.get("path")?.asString?.let { params["serviceName"] = it }
        }

        val user = JsonObject().apply {
            addProperty("id", uuid)
            addProperty("security", security)
        }

        val vnextItem = JsonObject().apply {
            addProperty("address", host)
            addProperty("port", port)
            add("users", JsonArray().apply { add(user) })
        }

        val outbound = JsonObject().apply {
            addProperty("tag", "proxy")
            addProperty("protocol", "vmess")
            add("settings", JsonObject().apply {
                add("vnext", JsonArray().apply { add(vnextItem) })
            })
            add("streamSettings", buildStreamSettings(params, host, defaultSecurity = "none"))
        }

        return VpnProfile(
            name = remark,
            protocol = "VMESS",
            rawUri = link,
            host = host,
            port = port,
            outboundJson = gson.toJson(outbound)
        )
    }

    private fun parseShadowsocks(link: String): VpnProfile {
        val withoutScheme = link.substringAfter("://")
        val fragment = withoutScheme.substringAfter("#", "")
        val remark = decodeUriComponent(fragment)
        val mainPart = withoutScheme.substringBefore("#").substringBefore("?")

        val method: String
        val password: String
        val host: String
        val port: Int

        if (mainPart.contains("@")) {
            val userInfoRaw = mainPart.substringBefore("@")
            val hostPort = mainPart.substringAfter("@").substringBefore("/")
            val userInfo = if (userInfoRaw.contains(":")) {
                decodeUriComponent(userInfoRaw)
            } else {
                decodeBase64Flex(userInfoRaw)
            }
            method = userInfo.substringBefore(":")
            password = userInfo.substringAfter(":")
            host = hostPort.substringBeforeLast(":").trim('[', ']')
            port = hostPort.substringAfterLast(":").toInt()
        } else {
            val decoded = decodeBase64Flex(mainPart)
            val userInfo = decoded.substringBefore("@")
            val hostPort = decoded.substringAfter("@").substringBefore("/")
            method = userInfo.substringBefore(":")
            password = userInfo.substringAfter(":")
            host = hostPort.substringBeforeLast(":").trim('[', ']')
            port = hostPort.substringAfterLast(":").toInt()
        }

        val server = JsonObject().apply {
            addProperty("address", host)
            addProperty("port", port)
            addProperty("method", method)
            addProperty("password", password)
        }

        val outbound = JsonObject().apply {
            addProperty("tag", "proxy")
            addProperty("protocol", "shadowsocks")
            add("settings", JsonObject().apply {
                add("servers", JsonArray().apply { add(server) })
            })
        }

        return VpnProfile(
            name = remark.ifBlank { "$host:$port" },
            protocol = "SS",
            rawUri = link,
            host = host,
            port = port,
            outboundJson = gson.toJson(outbound)
        )
    }

    private fun buildStreamSettings(
        params: Map<String, String>,
        defaultHost: String,
        defaultSecurity: String
    ): JsonObject {
        val networkRaw = params["type"]?.lowercase()?.ifBlank { "tcp" } ?: "tcp"
        val network = when (networkRaw) {
            "tcp" -> "raw"
            "splithttp" -> "xhttp"
            else -> networkRaw
        }
        val security = params["security"]?.lowercase()?.ifBlank { defaultSecurity } ?: defaultSecurity

        return JsonObject().apply {
            addProperty("network", network)
            addProperty("security", security)

            when (security) {
                "tls" -> {
                    add("tlsSettings", JsonObject().apply {
                        val sni = params["sni"]?.ifBlank { params["host"] }?.ifBlank { defaultHost } ?: defaultHost
                        addProperty("serverName", sni)
                        val fp = params["fp"]?.ifBlank { "chrome" } ?: "chrome"
                        addProperty("fingerprint", fp)
                        val allowInsecure = params["allowInsecure"] == "1" || params["allowInsecure"].equals("true", true)
                        if (allowInsecure) {
                            addProperty("allowInsecure", true)
                        }
                        val alpn = params["alpn"]
                        if (!alpn.isNullOrBlank()) {
                            add("alpn", JsonArray().apply {
                                alpn.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { add(it) }
                            })
                        }
                    })
                }
                "reality" -> {
                    add("realitySettings", JsonObject().apply {
                        val sni = params["sni"]?.ifBlank { defaultHost } ?: defaultHost
                        addProperty("serverName", sni)
                        addProperty("fingerprint", params["fp"]?.ifBlank { "chrome" } ?: "chrome")
                        addProperty("publicKey", params["pbk"] ?: "")
                        addProperty("shortId", params["sid"] ?: "")
                        addProperty("spiderX", params["spx"] ?: "")
                    })
                }
            }

            when (network) {
                "ws" -> {
                    add("wsSettings", JsonObject().apply {
                        addProperty("path", params["path"]?.ifBlank { "/" } ?: "/")
                        val wsHost = params["host"]
                        if (!wsHost.isNullOrBlank()) {
                            addProperty("host", wsHost)
                        }
                    })
                }
                "grpc" -> {
                    add("grpcSettings", JsonObject().apply {
                        addProperty("serviceName", params["serviceName"] ?: params["path"] ?: "")
                        if (params["mode"] == "multi") {
                            addProperty("multiMode", true)
                        }
                    })
                }
                "httpupgrade" -> {
                    add("httpupgradeSettings", JsonObject().apply {
                        addProperty("path", params["path"]?.ifBlank { "/" } ?: "/")
                        val h = params["host"]
                        if (!h.isNullOrBlank()) addProperty("host", h)
                    })
                }
                "xhttp" -> {
                    add("xhttpSettings", JsonObject().apply {
                        addProperty("path", params["path"]?.ifBlank { "/" } ?: "/")
                        val h = params["host"]
                        if (!h.isNullOrBlank()) addProperty("host", h)
                        val mode = params["mode"]
                        if (!mode.isNullOrBlank()) addProperty("mode", mode)
                    })
                }
            }
        }
    }

    fun buildFullXrayConfig(profile: VpnProfile): String {
        val root = JsonObject().apply {
            add("log", JsonObject().apply {
                addProperty("loglevel", "warning")
            })

            add("inbounds", JsonArray().apply {
                add(JsonObject().apply {
                    addProperty("tag", "tun-in")
                    addProperty("port", 0)
                    addProperty("protocol", "tun")
                    add("settings", JsonObject().apply {
                        addProperty("name", "xray0")
                        addProperty("mtu", 1500)
                    })
                    add("sniffing", JsonObject().apply {
                        addProperty("enabled", true)
                        add("destOverride", JsonArray().apply {
                            add("http")
                            add("tls")
                            add("quic")
                        })
                    })
                })
            })

            add("outbounds", JsonArray().apply {
                add(JsonParser.parseString(profile.outboundJson).asJsonObject)
                add(JsonObject().apply {
                    addProperty("tag", "direct")
                    addProperty("protocol", "freedom")
                })
            })

            add("routing", JsonObject().apply {
                addProperty("domainStrategy", "AsIs")
                add("rules", JsonArray().apply {
                    add(JsonObject().apply {
                        addProperty("type", "field")
                        add("ip", JsonArray().apply {
                            add("10.0.0.0/8")
                            add("172.16.0.0/12")
                            add("192.168.0.0/16")
                            add("127.0.0.0/8")
                        })
                        addProperty("outboundTag", "direct")
                    })
                })
            })
        }
        return gson.toJson(root)
    }

    private fun parseQuery(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrBlank()) return emptyMap()
        return rawQuery.split("&")
            .mapNotNull { pair ->
                val idx = pair.indexOf('=')
                if (idx <= 0) null
                else decodeUriComponent(pair.substring(0, idx)) to decodeUriComponent(pair.substring(idx + 1))
            }
            .toMap()
    }

    private fun decodeUriComponent(value: String?): String {
        if (value.isNullOrEmpty()) return ""
        return try {
            URLDecoder.decode(value.replace("+", "%2B"), "UTF-8")
        } catch (_: Exception) {
            value
        }
    }

    private fun decodeBase64Flex(input: String): String {
        val cleaned = input.trim().replace('-', '+').replace('_', '/').filter { !it.isWhitespace() }
        val padded = when (cleaned.length % 4) {
            2 -> "$cleaned=="
            3 -> "$cleaned="
            else -> cleaned
        }
        return String(Base64.decode(padded, Base64.DEFAULT), Charsets.UTF_8)
    }
}
