package com.simplevpn.app

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import com.simplevpn.app.data.AppSettings
import com.simplevpn.app.data.RoutingMode
import com.simplevpn.app.data.Storage
import com.simplevpn.app.data.VpnProfile
import com.simplevpn.app.data.VpnStatus
import com.simplevpn.app.parser.LinkParser
import com.simplevpn.app.vpn.AppWatcherService
import com.simplevpn.app.vpn.MyVpnService
import com.simplevpn.app.vpn.VpnStateHolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import libv2ray.Libv2ray

private val BgDark = Color(0xFF0F1117)
private val CardDark = Color(0xFF1A1E29)
private val CardBorder = Color(0xFF282E3E)
private val AccentIndigo = Color(0xFF6366F1)
private val AccentGreen = Color(0xFF22C55E)
private val AccentAmber = Color(0xFFF59E0B)
private val TextPrimary = Color(0xFFF3F4F6)
private val TextSecondary = Color(0xFF9CA3AF)

data class InstalledApp(
    val name: String,
    val packageName: String,
    val icon: ImageBitmap?
)

class MainActivity : ComponentActivity() {

    private var pendingVpnStartAction: (() -> Unit)? = null

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            pendingVpnStartAction?.invoke()
        } else {
            Toast.makeText(this, "Нужно разрешение на создание VPN", Toast.LENGTH_SHORT).show()
        }
        pendingVpnStartAction = null
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val storage = Storage(this)
        if (storage.getSettings().autoConnectOnAppLaunch && AppWatcherService.hasUsageAccess(this)) {
            AppWatcherService.start(this)
        }

        setContent {
            SimpleVpnTheme {
                MainScreen(
                    requestVpnPermissionThen = { action ->
                        val prepIntent = VpnService.prepare(this)
                        if (prepIntent != null) {
                            pendingVpnStartAction = action
                            vpnPermissionLauncher.launch(prepIntent)
                        } else {
                            action()
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun SimpleVpnTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = AccentIndigo,
        background = BgDark,
        surface = CardDark,
        onBackground = TextPrimary,
        onSurface = TextPrimary
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@Composable
fun MainScreen(requestVpnPermissionThen: (() -> Unit) -> Unit) {
    val context = LocalContext.current
    val storage = remember { Storage(context) }
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) }
    var profiles by remember { mutableStateOf(storage.getProfiles()) }
    var settings by remember { mutableStateOf(storage.getSettings()) }
    var showAddDialog by remember { mutableStateOf(false) }
    var isImporting by remember { mutableStateOf(false) }

    val vpnStatus by VpnStateHolder.status.collectAsState()
    val pingMs by VpnStateHolder.pingMs.collectAsState()
    val logs by VpnStateHolder.logs.collectAsState()

    fun updateSettings(newSettings: AppSettings) {
        settings = newSettings
        storage.saveSettings(newSettings)
    }

    fun updateProfiles(newProfiles: List<VpnProfile>, autoSelectId: String? = null) {
        profiles = newProfiles
        storage.saveProfiles(newProfiles)
        val currentId = autoSelectId ?: settings.selectedProfileId
        val validId = newProfiles.find { it.id == currentId }?.id ?: newProfiles.firstOrNull()?.id
        if (validId != settings.selectedProfileId) {
            updateSettings(settings.copy(selectedProfileId = validId))
        }
    }

    fun importFromText(raw: String) {
        scope.launch {
            isImporting = true
            try {
                val parsed = withContext(Dispatchers.IO) { LinkParser.importInput(raw) }
                if (parsed.isEmpty()) {
                    Toast.makeText(
                        context,
                        "Не найдено ссылок vless/vmess/trojan/ss",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    val updated = profiles + parsed
                    updateProfiles(updated, autoSelectId = parsed.first().id)
                    Toast.makeText(
                        context,
                        "Добавлено серверов: ${parsed.size}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                isImporting = false
            }
        }
    }

    Scaffold(
        containerColor = BgDark,
        bottomBar = {
            NavigationBar(containerColor = CardDark, tonalElevation = 0.dp) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Rounded.Shield, contentDescription = null) },
                    label = { Text("VPN") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Rounded.Apps, contentDescription = null) },
                    label = { Text("Приложения") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Rounded.Terminal, contentDescription = null) },
                    label = { Text("Логи") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> HomeTab(
                    vpnStatus = vpnStatus,
                    pingMs = pingMs,
                    profiles = profiles,
                    settings = settings,
                    isImporting = isImporting,
                    onToggleConnect = {
                        if (vpnStatus == VpnStatus.DISCONNECTED) {
                            if (profiles.isEmpty()) {
                                Toast.makeText(context, "Сначала добавь VPN-ссылку", Toast.LENGTH_SHORT).show()
                            } else {
                                requestVpnPermissionThen {
                                    MyVpnService.start(context, settings.selectedProfileId)
                                }
                            }
                        } else {
                            MyVpnService.stop(context)
                        }
                    },
                    onSelectProfile = { profile ->
                        updateSettings(settings.copy(selectedProfileId = profile.id))
                        if (vpnStatus == VpnStatus.CONNECTED) {
                            requestVpnPermissionThen {
                                MyVpnService.start(context, profile.id)
                            }
                        }
                    },
                    onDeleteProfile = { profile ->
                        updateProfiles(profiles.filterNot { it.id == profile.id })
                    },
                    onPasteClipboard = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clipText = cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()
                        if (clipText.isNullOrBlank()) {
                            Toast.makeText(context, "Буфер обмена пуст", Toast.LENGTH_SHORT).show()
                        } else {
                            importFromText(clipText)
                        }
                    },
                    onOpenAddDialog = { showAddDialog = true }
                )

                1 -> AppsTab(
                    settings = settings,
                    onUpdateSettings = { updated ->
                        updateSettings(updated)
                        if (updated.autoConnectOnAppLaunch) {
                            if (AppWatcherService.hasUsageAccess(context)) {
                                requestVpnPermissionThen {
                                    AppWatcherService.start(context)
                                }
                            }
                        } else {
                            AppWatcherService.stop(context)
                        }
                    },
                    onRestartVpnIfConnected = {
                        if (vpnStatus == VpnStatus.CONNECTED) {
                            requestVpnPermissionThen {
                                MyVpnService.start(context, settings.selectedProfileId)
                            }
                        }
                    }
                )

                2 -> LogsTab(
                    logs = logs,
                    onClear = { VpnStateHolder.clearLogs() }
                )
            }
        }
    }

    if (showAddDialog) {
        AddLinkDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { text ->
                showAddDialog = false
                importFromText(text)
            }
        )
    }
}

@Composable
fun HomeTab(
    vpnStatus: VpnStatus,
    pingMs: Long?,
    profiles: List<VpnProfile>,
    settings: AppSettings,
    isImporting: Boolean,
    onToggleConnect: () -> Unit,
    onSelectProfile: (VpnProfile) -> Unit,
    onDeleteProfile: (VpnProfile) -> Unit,
    onPasteClipboard: () -> Unit,
    onOpenAddDialog: () -> Unit
) {
    val activeProfile = profiles.find { it.id == settings.selectedProfileId } ?: profiles.firstOrNull()

    val buttonColor by animateColorAsState(
        targetValue = when (vpnStatus) {
            VpnStatus.CONNECTED -> AccentGreen
            VpnStatus.CONNECTING -> AccentAmber
            VpnStatus.DISCONNECTED -> AccentIndigo
        },
        label = "btnColor"
    )

    val statusText = when (vpnStatus) {
        VpnStatus.CONNECTED -> "Подключено"
        VpnStatus.CONNECTING -> "Подключение..."
        VpnStatus.DISCONNECTED -> "Отключено"
    }

    val modeLabel = when (settings.routingMode) {
        RoutingMode.ALL -> "Весь трафик"
        RoutingMode.BYPASS -> "Обход: ${settings.bypassPackages.size} прил."
        RoutingMode.ONLY_APPS -> "Только выбранные: ${settings.alwaysVpnPackages.size} прил."
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Верхняя панель
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SimpleVPN",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = modeLabel + if (settings.autoConnectOnAppLaunch) " • Авторежим" else "",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalIconButton(onClick = onPasteClipboard) {
                    Icon(Icons.Rounded.ContentPaste, contentDescription = "Вставить из буфера")
                }
                FilledTonalIconButton(onClick = onOpenAddDialog) {
                    Icon(Icons.Rounded.Add, contentDescription = "Добавить вручную")
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Центральная кнопка подключения
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(164.dp)
                    .clip(CircleShape)
                    .background(buttonColor.copy(alpha = 0.16f))
                    .border(2.dp, buttonColor.copy(alpha = 0.6f), CircleShape)
                    .clickable(onClick = onToggleConnect),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(124.dp)
                        .clip(CircleShape)
                        .background(buttonColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PowerSettingsNew,
                        contentDescription = "Включить или выключить VPN",
                        tint = Color.White,
                        modifier = Modifier.size(56.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = statusText,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = buttonColor
            )

            val subline = buildString {
                if (activeProfile != null) {
                    append(activeProfile.name)
                    if (pingMs != null && vpnStatus == VpnStatus.CONNECTED) {
                        append("  •  ${pingMs} мс")
                    }
                } else {
                    append("Добавь ссылку vless:// или подписку")
                }
            }
            Text(
                text = subline,
                fontSize = 13.sp,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Заголовок списка серверов
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Серверы (${profiles.size})",
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = TextSecondary
            )
            if (isImporting) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (profiles.isEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onPasteClipboard),
                colors = CardDefaults.cardColors(containerColor = CardDark),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Rounded.Link,
                        contentDescription = null,
                        tint = AccentIndigo,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Нажми, чтобы вставить ссылку из буфера",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Поддерживаются vless://, vmess://, trojan://, ss:// и URL подписок",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(profiles, key = { it.id }) { profile ->
                    val isSelected = profile.id == activeProfile?.id
                    val borderColor = if (isSelected) AccentIndigo else CardBorder
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(CardDark)
                            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
                            .clickable { onSelectProfile(profile) }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(AccentIndigo.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = profile.protocol,
                                color = AccentIndigo,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = profile.name,
                                color = TextPrimary,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${profile.host}:${profile.port}",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (isSelected) {
                            Icon(
                                Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = AccentGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        IconButton(onClick = { onDeleteProfile(profile) }) {
                            Icon(
                                Icons.Rounded.DeleteOutline,
                                contentDescription = "Удалить",
                                tint = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppsTab(
    settings: AppSettings,
    onUpdateSettings: (AppSettings) -> Unit,
    onRestartVpnIfConnected: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var installedApps by remember { mutableStateOf<List<InstalledApp>>(emptyList()) }
    var isLoadingApps by remember { mutableStateOf(true) }
    var hasUsageAccess by remember { mutableStateOf(AppWatcherService.hasUsageAccess(context)) }

    // 0 = список «Всегда VPN» (для режима "Только выбранные" и автозапуска)
    // 1 = список «Обход VPN» (для режима "Обход")
    var listTab by remember {
        mutableIntStateOf(if (settings.routingMode == RoutingMode.BYPASS) 1 else 0)
    }

    LaunchedEffect(Unit) {
        val apps = withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
            resolveInfos
                .mapNotNull { info ->
                    val pkg = info.activityInfo.packageName
                    if (pkg == context.packageName) return@mapNotNull null
                    val label = info.loadLabel(pm)?.toString() ?: pkg
                    val icon = runCatching {
                        info.loadIcon(pm).toBitmap(72, 72).asImageBitmap()
                    }.getOrNull()
                    InstalledApp(label, pkg, icon)
                }
                .distinctBy { it.packageName }
                .sortedBy { it.name.lowercase() }
        }
        installedApps = apps
        isLoadingApps = false
    }

    val activeSet = if (listTab == 0) settings.alwaysVpnPackages else settings.bypassPackages

    val filteredApps = remember(installedApps, searchQuery, activeSet) {
        val q = searchQuery.trim().lowercase()
        installedApps
            .filter {
                q.isEmpty() || it.name.lowercase().contains(q) || it.packageName.lowercase().contains(q)
            }
            .sortedWith(
                compareByDescending<InstalledApp> { activeSet.contains(it.packageName) }
                    .thenBy { it.name.lowercase() }
            )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text(
            text = "Приложения и маршрутизация",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Выбор режима туннелирования
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CardDark)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ModeChip(
                text = "Весь трафик",
                selected = settings.routingMode == RoutingMode.ALL,
                modifier = Modifier.weight(1f),
                onClick = {
                    onUpdateSettings(settings.copy(routingMode = RoutingMode.ALL))
                    onRestartVpnIfConnected()
                }
            )
            ModeChip(
                text = "Обход",
                selected = settings.routingMode == RoutingMode.BYPASS,
                modifier = Modifier.weight(1f),
                onClick = {
                    listTab = 1
                    onUpdateSettings(settings.copy(routingMode = RoutingMode.BYPASS))
                    onRestartVpnIfConnected()
                }
            )
            ModeChip(
                text = "Только выбр.",
                selected = settings.routingMode == RoutingMode.ONLY_APPS,
                modifier = Modifier.weight(1f),
                onClick = {
                    listTab = 0
                    onUpdateSettings(settings.copy(routingMode = RoutingMode.ONLY_APPS))
                    onRestartVpnIfConnected()
                }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Карточка автозапуска VPN при открытии выбранного приложения
        Card(
            colors = CardDefaults.cardColors(containerColor = CardDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Авто-VPN при открытии",
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                        Text(
                            "Сам включит VPN, когда откроешь приложение из списка «Всегда VPN»",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = settings.autoConnectOnAppLaunch,
                        onCheckedChange = { enabled ->
                            hasUsageAccess = AppWatcherService.hasUsageAccess(context)
                            if (enabled && !hasUsageAccess) {
                                Toast.makeText(
                                    context,
                                    "Дай SimpleVPN доступ к данным об использовании и вернись назад",
                                    Toast.LENGTH_LONG
                                ).show()
                                context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                            } else {
                                onUpdateSettings(settings.copy(autoConnectOnAppLaunch = enabled))
                            }
                        }
                    )
                }

                if (settings.autoConnectOnAppLaunch) {
                    HorizontalDivider(
                        color = CardBorder,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Отключать VPN после выхода из приложения",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = settings.autoDisconnectOnAppExit,
                            onCheckedChange = {
                                onUpdateSettings(settings.copy(autoDisconnectOnAppExit = it))
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Переключатель редактируемого списка
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = listTab == 0,
                onClick = { listTab = 0 },
                label = { Text("Всегда VPN (${settings.alwaysVpnPackages.size})") }
            )
            FilterChip(
                selected = listTab == 1,
                onClick = { listTab = 1 },
                label = { Text("Обход (${settings.bypassPackages.size})") }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Поиск приложения...") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (isLoadingApps) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredApps, key = { it.packageName }) { app ->
                    val checked = activeSet.contains(app.packageName)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CardDark)
                            .clickable {
                                val nextSet = activeSet.toMutableSet().apply {
                                    if (checked) remove(app.packageName) else add(app.packageName)
                                }
                                val updated = if (listTab == 0) {
                                    settings.copy(alwaysVpnPackages = nextSet)
                                } else {
                                    settings.copy(bypassPackages = nextSet)
                                }
                                onUpdateSettings(updated)
                                onRestartVpnIfConnected()
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (app.icon != null) {
                            Image(
                                bitmap = app.icon,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        } else {
                            Icon(
                                Icons.Rounded.Android,
                                contentDescription = null,
                                modifier = Modifier.size(36.dp),
                                tint = TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = app.name,
                                color = TextPrimary,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = app.packageName,
                                color = TextSecondary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Checkbox(
                            checked = checked,
                            onCheckedChange = null
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ModeChip(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(9.dp))
            .background(if (selected) AccentIndigo else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (selected) Color.White else TextSecondary,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1
        )
    }
}

@Composable
fun LogsTab(logs: List<String>, onClear: () -> Unit) {
    val context = LocalContext.current
    val coreVersion = remember {
        runCatching { Libv2ray.checkVersionX() }.getOrDefault("Xray-core")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Журнал и система",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = coreVersion,
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
            TextButton(onClick = onClear) {
                Text("Очистить")
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedButton(
            onClick = {
                context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Rounded.Settings, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Открыть системные настройки VPN (Постоянная VPN)")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = CardDark),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            if (logs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Логов пока нет", color = TextSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(logs) { line ->
                        Text(
                            text = line,
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AddLinkDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var input by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardDark,
        title = { Text("Добавить VPN-ссылку", color = TextPrimary) },
        text = {
            Column {
                Text(
                    "Вставь ссылку vless://, vmess://, trojan://, ss:// или URL-подписку (https://...)",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text("vless://...") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(input) },
                enabled = input.isNotBlank()
            ) {
                Text("Добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}
