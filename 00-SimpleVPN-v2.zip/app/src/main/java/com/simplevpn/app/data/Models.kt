package com.simplevpn.app.data

import java.util.UUID

enum class RoutingMode {
    ALL,        // Весь трафик через VPN
    BYPASS,     // Обход выбранных приложений (чёрный список)
    ONLY_APPS   // VPN работает ТОЛЬКО для выбранных приложений (белый список)
}

enum class VpnStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED
}

data class VpnProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val protocol: String,
    val rawUri: String,
    val host: String,
    val port: Int,
    val outboundJson: String
)

data class AppSettings(
    val routingMode: RoutingMode = RoutingMode.ALL,
    val bypassPackages: Set<String> = emptySet(),
    val alwaysVpnPackages: Set<String> = emptySet(),
    val autoConnectOnAppLaunch: Boolean = false,
    val autoDisconnectOnAppExit: Boolean = false,
    val selectedProfileId: String? = null
)
