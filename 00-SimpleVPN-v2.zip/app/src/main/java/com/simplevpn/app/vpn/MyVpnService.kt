package com.simplevpn.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.simplevpn.app.MainActivity
import com.simplevpn.app.R
import com.simplevpn.app.data.RoutingMode
import com.simplevpn.app.data.Storage
import com.simplevpn.app.data.VpnStatus
import com.simplevpn.app.parser.LinkParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

class MyVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.simplevpn.app.START_VPN"
        const val ACTION_STOP = "com.simplevpn.app.STOP_VPN"
        const val EXTRA_PROFILE_ID = "profile_id"
        const val EXTRA_FROM_WATCHER = "from_watcher"
        private const val CHANNEL_ID = "simple_vpn_channel"
        private const val NOTIFICATION_ID = 1001

        fun start(context: Context, profileId: String? = null, fromWatcher: Boolean = false) {
            val intent = Intent(context, MyVpnService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_PROFILE_ID, profileId)
                putExtra(EXTRA_FROM_WATCHER, fromWatcher)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, MyVpnService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var vpnInterface: ParcelFileDescriptor? = null
    private var coreController: CoreController? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpn()
                return START_NOT_STICKY
            }
            ACTION_START, null -> {
                val profileId = intent?.getStringExtra(EXTRA_PROFILE_ID)
                val fromWatcher = intent?.getBooleanExtra(EXTRA_FROM_WATCHER, false) ?: false
                startVpn(profileId, fromWatcher)
            }
        }
        return START_STICKY
    }

    private fun startVpn(requestedProfileId: String?, fromWatcher: Boolean) {
        val storage = Storage(this)
        val settings = storage.getSettings()
        val profiles = storage.getProfiles()
        val profile = profiles.find { it.id == (requestedProfileId ?: settings.selectedProfileId) }
            ?: profiles.firstOrNull()

        if (profile == null) {
            VpnStateHolder.addLog("Ошибка: нет добавленных серверов")
            VpnStateHolder.setStatus(VpnStatus.DISCONNECTED)
            stopSelf()
            return
        }

        VpnStateHolder.startedByWatcher = fromWatcher
        VpnStateHolder.setStatus(VpnStatus.CONNECTING, profile.name)
        VpnStateHolder.addLog("Запуск VPN: ${profile.name} (${profile.protocol})")

        createNotificationChannel()
        startForegroundCompat(buildNotification("Подключение к ${profile.name}..."))

        serviceScope.launch {
            try {
                stopCoreOnly()

                val builder = Builder()
                    .setSession("SimpleVPN")
                    .setMtu(1500)
                    .addAddress("10.0.0.2", 30)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer("1.1.1.1")
                    .addDnsServer("8.8.8.8")

                when (settings.routingMode) {
                    RoutingMode.ALL -> {
                        safeDisallow(builder, packageName)
                        VpnStateHolder.addLog("Режим: весь трафик через VPN")
                    }
                    RoutingMode.BYPASS -> {
                        safeDisallow(builder, packageName)
                        var bypassed = 0
                        settings.bypassPackages.forEach { pkg ->
                            if (pkg != packageName && safeDisallow(builder, pkg)) {
                                bypassed++
                            }
                        }
                        VpnStateHolder.addLog("Режим: обход $bypassed прил.")
                    }
                    RoutingMode.ONLY_APPS -> {
                        val allowed = settings.alwaysVpnPackages.filter { it != packageName }
                        if (allowed.isEmpty()) {
                            safeDisallow(builder, packageName)
                            VpnStateHolder.addLog("Список 'Только выбранные' пуст — включён весь трафик")
                        } else {
                            var count = 0
                            allowed.forEach { pkg ->
                                if (safeAllow(builder, pkg)) count++
                            }
                            if (count == 0) {
                                safeDisallow(builder, packageName)
                            }
                            VpnStateHolder.addLog("Режим: VPN только для $count прил.")
                        }
                    }
                }

                val tun = builder.establish()
                    ?: throw IllegalStateException("Не удалось создать TUN-интерфейс (нет разрешения VPN)")
                vpnInterface = tun

                Libv2ray.initCoreEnv(filesDir.absolutePath, "")
                val controller = Libv2ray.newCoreController(object : CoreCallbackHandler {
                    override fun startup(): Long {
                        VpnStateHolder.addLog("Ядро Xray запущено")
                        return 0L
                    }

                    override fun shutdown(): Long {
                        VpnStateHolder.addLog("Ядро Xray остановлено")
                        return 0L
                    }

                    override fun onEmitStatus(p0: Long, p1: String?): Long {
                        if (!p1.isNullOrBlank()) {
                            VpnStateHolder.addLog("Xray: $p1")
                        }
                        return 0L
                    }
                })
                coreController = controller

                val configJson = LinkParser.buildFullXrayConfig(profile)
                controller.startLoop(configJson, tun.fd)

                VpnStateHolder.setStatus(VpnStatus.CONNECTED, profile.name)
                updateNotification("Подключено: ${profile.name}")

                // Быстрый замер задержки после подключения
                runCatching {
                    val delay = controller.measureDelay("https://www.gstatic.com/generate_204")
                    if (delay > 0) {
                        VpnStateHolder.setPing(delay)
                        VpnStateHolder.addLog("Пинг: ${delay} мс")
                    }
                }
            } catch (e: Exception) {
                VpnStateHolder.addLog("Ошибка запуска: ${e.message}")
                stopVpn()
            }
        }
    }

    private fun safeDisallow(builder: Builder, pkg: String): Boolean {
        return try {
            builder.addDisallowedApplication(pkg)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun safeAllow(builder: Builder, pkg: String): Boolean {
        return try {
            builder.addAllowedApplication(pkg)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun stopCoreOnly() {
        try {
            coreController?.stopLoop()
        } catch (_: Exception) {
        }
        coreController = null
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }
        vpnInterface = null
    }

    private fun stopVpn() {
        stopCoreOnly()
        VpnStateHolder.setStatus(VpnStatus.DISCONNECTED)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        VpnStateHolder.addLog("VPN отключён системой")
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopCoreOnly()
        serviceScope.cancel()
        VpnStateHolder.setStatus(VpnStatus.DISCONNECTED)
        super.onDestroy()
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SimpleVPN Соединение",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, MyVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SimpleVPN")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_vpn_key)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Отключить", stopIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }
}
