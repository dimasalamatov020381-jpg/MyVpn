package com.simplevpn.app.vpn

import com.simplevpn.app.data.VpnStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object VpnStateHolder {
    private val _status = MutableStateFlow(VpnStatus.DISCONNECTED)
    val status: StateFlow<VpnStatus> = _status.asStateFlow()

    private val _activeProfileName = MutableStateFlow<String?>(null)
    val activeProfileName: StateFlow<String?> = _activeProfileName.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private val _pingMs = MutableStateFlow<Long?>(null)
    val pingMs: StateFlow<Long?> = _pingMs.asStateFlow()

    @Volatile
    var startedByWatcher: Boolean = false

    fun setStatus(newStatus: VpnStatus, profileName: String? = _activeProfileName.value) {
        _status.value = newStatus
        _activeProfileName.value = if (newStatus == VpnStatus.DISCONNECTED) null else profileName
        if (newStatus == VpnStatus.DISCONNECTED) {
            _pingMs.value = null
            startedByWatcher = false
        }
    }

    fun setPing(ms: Long?) {
        _pingMs.value = ms
    }

    fun addLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val updated = (_logs.value + "[$time] $message").takeLast(120)
        _logs.value = updated
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }
}
