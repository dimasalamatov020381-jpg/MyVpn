package com.simplevpn.app.vpn

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.Process
import androidx.core.app.NotificationCompat
import com.simplevpn.app.MainActivity
import com.simplevpn.app.R
import com.simplevpn.app.data.Storage
import com.simplevpn.app.data.VpnStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AppWatcherService : Service() {

    companion object {
        private const val CHANNEL_ID = "simple_vpn_watcher_channel"
        private const val NOTIFICATION_ID = 1002

        fun hasUsageAccess(context: Context): Boolean {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            }
            return mode == AppOpsManager.MODE_ALLOWED
        }

        fun start(context: Context) {
            val intent = Intent(context, AppWatcherService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, AppWatcherService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var currentForegroundPkg: String? = null
    private var awayTicks: Int = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        startWatching()
        return START_STICKY
    }

    private fun startWatching() {
        scope.launch {
            val usageStats = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val storage = Storage(this@AppWatcherService)
            val event = UsageEvents.Event()

            while (isActive) {
                delay(1500L)
                val settings = storage.getSettings()
                if (!settings.autoConnectOnAppLaunch) {
                    stopSelf()
                    break
                }
                if (!hasUsageAccess(this@AppWatcherService)) continue

                val now = System.currentTimeMillis()
                val events = usageStats.queryEvents(now - 5_000L, now)
                while (events.hasNextEvent()) {
                    events.getNextEvent(event)
                    val isResumed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
                    } else {
                        @Suppress("DEPRECATION")
                        event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
                    }
                    if (isResumed && !event.packageName.isNullOrBlank()) {
                        currentForegroundPkg = event.packageName
                    }
                }

                val pkg = currentForegroundPkg ?: continue
                if (pkg == packageName || pkg == "com.android.systemui") continue

                val isTargetApp = settings.alwaysVpnPackages.contains(pkg)
                val status = VpnStateHolder.status.value

                if (isTargetApp) {
                    awayTicks = 0
                    if (status == VpnStatus.DISCONNECTED && VpnService.prepare(this@AppWatcherService) == null) {
                        VpnStateHolder.addLog("Автозапуск VPN для $pkg")
                        MyVpnService.start(this@AppWatcherService, fromWatcher = true)
                    }
                } else if (settings.autoDisconnectOnAppExit &&
                    VpnStateHolder.startedByWatcher &&
                    status == VpnStatus.CONNECTED
                ) {
                    awayTicks++
                    if (awayTicks >= 3) {
                        awayTicks = 0
                        VpnStateHolder.addLog("Автоотключение VPN (выход из целевого приложения)")
                        MyVpnService.stop(this@AppWatcherService)
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Автозапуск VPN для приложений",
                NotificationManager.IMPORTANCE_MIN
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SimpleVPN Авторежим")
            .setContentText("Отслеживание приложений для автозапуска VPN")
            .setSmallIcon(R.drawable.ic_vpn_key)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .build()
    }
}
